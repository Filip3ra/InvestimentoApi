namespace InvestimentoApi.ViewModel;

public class InvestimentoViewModel
{
  public int Meses { get; set; }
  public List<string> ListaAnos { get; set; } = new List<string>();
}